package question2;
import java.util.Comparator;

// The generic type parameter should be of type Comparable as we are using compareTo function to sort
// Comparator Interface is implemented to make a user defined comparison of the objects

public class GenericComparator<T extends Comparable<T>> implements Comparator<T> {
	 T[] array;

	 public void sort(T[] array) { // array length must be a power of 2
	 this.array = array;
	 sort(0, array.length);
	 }
	 private void sort(int low, int n) {

	 if (n > 1) {
	 int mid = n >> 1;

	 sort(low, mid);
	 sort(low + mid, mid);

	 combine(low, n, 1);
	 }
	 }
	 private void combine(int low, int n, int st) {

	 int m = st << 1;

	 if (m < n) {
	 combine(low, n, m);
	 combine(low + st, n, m);

	 for (int i = low + st; i + st < low + n; i += m)
	 compareAndSwap(i, i + st);

	 } else
	 compareAndSwap(low, low + st);
	 }
	 private void compareAndSwap(int i, int j) {
		if(compare(array[i],array[j])>0) {
			swap(i, j);
		}
	 }
	 private void swap(int i, int j) {
	 T h = array[i];
	 array[i] = array[j];
	 array[j] = h;
	 }
	 //overriding the compare method of comparator interface
	 @Override
	 public int compare(T firstArg, T secondArg) {
		 //Returns 0 if the two parameters are equal, greater than 0 if the firstArg is greater and lesser than 0 if the firstArg is lesser
			return firstArg.compareTo(secondArg);
		}
	
}

