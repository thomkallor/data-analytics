package question2;

import java.util.Arrays;

import question2.GenericComparator;

public class PrintAnswer {
	public static void main(String[] args) {

		Integer[] inputIntArray= {1,3,3,4,5,9,7,8,9,2,11,19,13,14,16,15};
		GenericComparator<Integer> sortInt=new GenericComparator<Integer>();
		sortInt.sort(inputIntArray.clone());
		Integer[] outputIntArray=sortInt.array;
		System.out.println("Input array :");
		System.out.println(Arrays.toString(inputIntArray));
		System.out.println("Output array :");
		System.out.println(Arrays.toString(outputIntArray));
		
		
		Double[] inputDoubleArray= {1.78,2.07,3.78,4.34,5.21,6.786425,7.54436,8.23532,9.2654,10.4263,11.2345,12.3654346,13.2466636,14.34365,16.46436,15.35767};
		GenericComparator<Double> sortDouble=new GenericComparator<Double>();
		sortDouble.sort(inputDoubleArray.clone());
		Double[] outputDoubleArray=sortDouble.array;
		System.out.println("Input array :");
		System.out.println(Arrays.toString(inputDoubleArray));
		System.out.println("Output array :");
		System.out.println(Arrays.toString(outputDoubleArray));
		
		
		String[] inputStringArray= {"a","c","b","e","d","d","f","h","z","k","l","m","o","m","p","q"};
		GenericComparator<String> sortString=new GenericComparator<String>();
		sortString.sort(inputStringArray.clone());
		String[] outputStringArray=sortString.array;
		System.out.println("Input array :");
		System.out.println(Arrays.toString(inputStringArray));
		System.out.println("Output array :");
		System.out.println(Arrays.toString(outputStringArray));
	}

}
