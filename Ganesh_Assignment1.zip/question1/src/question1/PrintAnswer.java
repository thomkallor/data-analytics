package question1;

import java.util.Arrays;

import question1.SortArray;

public class PrintAnswer {
	public static void main(String[] args) {
		//Array with 16 elements work
		int[] inputIntArray= {1,3,3,4,5,9,7,8,9,2,11,19,13,14,16,15};
		SortArray sortInt=new SortArray();
		//Cloning to make a new array for sort since we need the original input array
		sortInt.sort(inputIntArray.clone());
		int[] outputIntArray=sortInt.array;
		System.out.println("Input array :");
		System.out.println(Arrays.toString(inputIntArray));
		System.out.println("Output array :");
		System.out.println(Arrays.toString(outputIntArray));
		
		
		//Array with 14 elements does not work null value in the property array 
		int[] inputArray14= {1,3,3,4,5,9,7,8,9,2,11,19,13,14};
		SortArray sortInt14=new SortArray();
		sortInt.sort(inputIntArray.clone());
		int[] outputArray14=sortInt14.array;
		System.out.println("Input array :");
		System.out.println(Arrays.toString(inputArray14));
		System.out.println("Output array :");
		System.out.println(Arrays.toString(outputArray14));
	}
}
