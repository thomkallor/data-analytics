package question4;
import java.util.Comparator;

//The type parameter must support comparison with other instances of its own type, via the Comparable interface
//Comparator Interface is implemented to make a user defined comparison of the objects

public class GenericComparator<T extends Comparable<T>> {
	 T[] array;

	 public void sort(T[] array) { // array length must be a power of 2
	 this.array = array;
	 //number of cores available in computer
	 int numOfCores = Runtime.getRuntime().availableProcessors();
	 sortParallel(0, array.length,numOfCores);
	 }
	 private Thread createSortThread(int low, int n, int numOfThreads) {
		 return new Thread() {
			 @Override
			 public void run() {
				 //numOfThreads represent the no of threads available for each sorter.
				 // since we are going to run two parallel sorts we are dividing it by two
				 sortParallel(low, n, numOfThreads/2);
			 }
		 };
	 }
		private void sortParallel(int low, int n, int numOfThreads) {
			//if the number of available cores for each block is one or zero use sequential sorting(sort method)
			// Does not make sense to keep on creating thread when there are no cores available
			if(numOfThreads<2) {
				sort(low, n);
				return;
			}
		 if (n > 1) { 
			int mid = n >> 1;
			//Dividing into two threads left and right, passing the respective blocks of the array
			Thread leftHalf=createSortThread(low,mid,numOfThreads);
			Thread RightHalf=createSortThread(low+mid,mid,numOfThreads);
			leftHalf.run();
			RightHalf.run();
			
			try {
				//Waiting for the left half and right half threads to complete
				leftHalf.join();
				RightHalf.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			//Combining the two separated halves
			combine(low,n,1);
		 } 
		}
		 private void sort(int low, int n) {
			 if (n > 1) {
			 int mid = n >> 1;

			 sort(low, mid);
			 sort(low + mid, mid);

			 combine(low, n, 1);
			 }
			 }
			 private void combine(int low, int n, int st) {

			 int m = st << 1;

			 if (m < n) {
			 combine(low, n, m);
			 combine(low + st, n, m);

			 for (int i = low + st; i + st < low + n; i += m)
			 compareAndSwap(i, i + st);

			 } else
			 compareAndSwap(low, low + st);
			 }
			 private void compareAndSwap(int i, int j) {
				 //Using a lambda function to use the compare function of the comparator interface
				 Comparator<T> customComparator=(T firstArg,T secondArg)-> firstArg.compareTo(secondArg);
				if(customComparator.compare(array[i],array[j])>0) {
					swap(i, j);
				}
			 }
			 private void swap(int i, int j) {
			 T h = array[i];
			 array[i] = array[j];
			 array[j] = h;
			 }

}