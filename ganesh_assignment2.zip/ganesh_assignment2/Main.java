package Assignment2;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Main {

	public static void main(String[] args) {
		//Creating a list of measurements
		List<Measurement> measurements= new ArrayList<>(
				List.of(new Measurement(12,23.5795),
						new Measurement(13,12.567),
						new Measurement(13,12.97),
						new Measurement(14,30.7987),
						new Measurement(10,18.567),
						new Measurement(4,14.8967))
				);
		//Creating weather station Dublin using the measurements created
		WeatherStation dublin=new WeatherStation("Dublin",measurements);
		//Calling maxTemperature method
		double maxTemperature=dublin.maxTemperature(10, 13);
		System.out.println("Maximum temperature :");
		System.out.println(maxTemperature);
		
		//Creating weather station Galway using the measurements created
		WeatherStation galway=new WeatherStation("Galway",measurements);
		//Adding the stations created to the static variable in WeatherStation Class
		WeatherStation.stations.add(dublin);
		WeatherStation.stations.add(galway);
		
		//Calling countTemperatures method
		List<Map<Double,Long>> temperatureGroups =dublin.countTemperatures(23, 12, 1);
	
		//Looping the result list of key,value
		temperatureGroups.forEach(map->{
			map.forEach((key,value) -> {
				System.out.printf("Count of Temperature %.2f is %d \n",key,value);
			});
		});
	}
}
