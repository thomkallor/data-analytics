package Assignment2;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

public class WeatherStation {
	public String city;
	public List<Measurement> measurements;
	public static List<WeatherStation> stations = new ArrayList<>();

	//Constructor to instantiate object with given values
	public WeatherStation(String city, List<Measurement> measurements) {
		this.city = city;
		this.measurements = measurements;
	}

	public double maxTemperature(int startTime, int endTime) {
		Measurement maxMeasurement = measurements.stream()
				//Filtering the measurement between the given time
				.filter(measurement -> measurement.time >= startTime && measurement.time <= endTime)
				//finding the max of the measurements
				//comparing is used to customize the max method
				.max(Comparator.comparing(measurement -> measurement.temperature))
				//max returns Optional class instance so throwing an error if nothing is found
				.orElseThrow(NoSuchElementException::new);
		return maxMeasurement.temperature;
	}

	
	public List<Map<Double,Long>> countTemperatures(double t1, double t2, double r) {
		List<Double> temperatureKeys=new ArrayList<>();
		temperatureKeys.add(t1);
		temperatureKeys.add(t2);
			//Creating a list of measurements 
			List<Measurement> flattenedMeasurements = stations.parallelStream()
		  	//Using flatmap to get a list of parallel stream instead List of List, flattening the array
		  	.flatMap(station -> station.measurements.parallelStream())
		  	.collect(Collectors.toList());
			
		  	// Shuffling/Grouping- using filter if temperature is within range
			//Creating a list of list (key,value) - (temperature,count) 
			List<List<TemperatureGroup>> groupByTemperature= new ArrayList<List<TemperatureGroup>>();
			for(double t : temperatureKeys ) {
				//Shuffling/Grouping the List by actual Value List of (t1,1) or (t2,1)
				List<TemperatureGroup> tGroup= flattenedMeasurements.parallelStream()
						//filter by range from all measurements
				.filter(measurement -> measurement.temperature >= t - r && measurement.temperature <= t + r)
						//Making each measurement of key,value pairs
				.map(measurement->new TemperatureGroup(t))
				.collect(Collectors.toList());
				//adding t1 and t2 group to a list
				groupByTemperature.add(tGroup);
			}
			
			List<Map<Double,Long>> reducedResult = new ArrayList<Map<Double,Long>>();
			for(List<TemperatureGroup> tGroup : groupByTemperature ) {
				//Reducing the result making the count of temperature
				//Gives (t1,count) or (t2,count)
				Map<Double,Long> groupMap= new HashMap<Double,Long>();
				groupMap = tGroup.stream().collect(Collectors.groupingBy(TemperatureGroup::getTemperature,Collectors.counting()));
				reducedResult.add(groupMap);
			}
		return reducedResult;
	}
	
}
