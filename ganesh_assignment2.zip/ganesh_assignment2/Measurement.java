package Assignment2;

public class Measurement {
public int time;
public double temperature;

//Constructor to instantiate object with given values
public Measurement(int time,double temperature){
	this.time=time;
	this.temperature=temperature;
}
}
