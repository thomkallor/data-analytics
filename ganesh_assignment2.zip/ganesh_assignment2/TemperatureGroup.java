package Assignment2;

//Created Class TemperatureGroup to act as a key value pair
public class TemperatureGroup {
	
	public double temperature;
	public long count=1;
	
	//Constructor to instantiate object with given values
	public TemperatureGroup(double temperature) {
		this.temperature=temperature;
	}
	public TemperatureGroup(Double temperature) {
		this.temperature=temperature;
	}
	public TemperatureGroup(double temperature,long count) {
		this.temperature=temperature;
		this.count=count;
	}
	
	public double getTemperature() {
		return temperature;
	}
	public void setTemperature(double temperature) {
		this.temperature = temperature;
	}
	public long getCount() {
		return count;
	}
	public void setCount(long count) {
		this.count = count;
	}
	@Override
	public String toString() {
		return "TemperatureGroup [temperature=" + temperature + ", count=" + count + "]";
	}
}
