
package assignment3;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

//Implementing Serializable makes the WeatherStation Serializable to be used by spark
public class WeatherStation_Q1 implements Serializable {
	private static final long serialVersionUID = 5504235123389683196L;
	public String city;
	public List<Measurement_Q1> measurements;
	public static List<WeatherStation_Q1> stations = new ArrayList<>();
	public static SparkConf sparkConf = new SparkConf().setAppName("TempCount")
			.setMaster("local[4]").set("spark.executor.memory", "1g");

	//Constructor to instantiate object with given values
	public WeatherStation_Q1(String city, List<Measurement_Q1> measurements) {
		this.city = city;
		this.measurements = measurements;
	}
	
	public static long countTemperatures(double t) {
		//Initiating JavaSparkContext to work with Java collections
		JavaSparkContext ctx = new JavaSparkContext(sparkConf);
		//Parallelize makes the collection to a Rdd
		//Making a JavaRdd of temperatures in each station
		JavaRDD<Double> readings=ctx.parallelize(stations)
							  .flatMap(station->station.measurements.iterator())
							  .map(measurement->measurement.temperature);
		//Filtering the temperatures in the range and making a count of them
		long count=readings.filter(reading-> reading>=t-1 && reading<=t+1).count();
		ctx.close();
		return count;
	}
	
}

