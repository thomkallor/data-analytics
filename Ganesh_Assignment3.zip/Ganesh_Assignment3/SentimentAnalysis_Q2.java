package assignment3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.mllib.classification.SVMModel;
import org.apache.spark.mllib.classification.SVMWithSGD;
import org.apache.spark.mllib.evaluation.BinaryClassificationMetrics;
import org.apache.spark.mllib.feature.HashingTF;
import org.apache.spark.mllib.regression.LabeledPoint;

import scala.Tuple2;

public class SentimentAnalysis_Q2 {
	public static List<WeatherStation_Q1> stations = new ArrayList<>();
	public static SparkConf sparkConf = new SparkConf().setAppName("SentimentAnalysis")
			.setMaster("local[4]").set("spark.executor.memory", "1g");
	
	public static void analyse() {
		//Initiating JavaSparkContext to work with Java collections
		JavaSparkContext sc = new JavaSparkContext(sparkConf);
		//Reading the data and making it into a JavaRdd of tuples
		JavaRDD<Tuple2<String,Integer>> data = sc.textFile("target/imdb_labelled.txt")
				.map(line->line.split("\\t")).map(line->new Tuple2<>(line[0],Integer.parseInt(line[1])));
		//Used to Map a sequence of term to their term frequencies with no. of features as 8000
		HashingTF tf = new HashingTF(8000);
		//Spilt the data into two training and test
		JavaRDD<Tuple2<String, Integer>>[] splitData= data.randomSplit(new double[]{0.6,0.4});
		JavaRDD<Tuple2<String, Integer>> trainingData =splitData[0];
		JavaRDD<Tuple2<String, Integer>> testData =splitData[1];
		//Making labeledpoint to train the model with 1 and 0 as labels and sentiments as features 
		JavaRDD<LabeledPoint> trainingLabeled=trainingData.map(line->  new LabeledPoint(line._2(), tf.transform(Arrays.asList(line._1().split(" ")))));
		//Making labeledpoint to evaluate the model with 1 and 0 as labels and sentiments as features
		JavaRDD<LabeledPoint> testLabeled=testData.map(line->  new LabeledPoint(line._2(), tf.transform(Arrays.asList(line._1().split(" ")))));
		//Training the sample data with 1000 internal iterations
		SVMModel model = SVMWithSGD.train(trainingLabeled.rdd(), 1000);
		//Print the predicted results
		testData.take(10).forEach(line->{
			System.out.print(line._1()+": ");
			System.out.print(model.predict(tf.transform(Arrays.asList(line._1().split(" "))))+"\n");
		});
		//making a tuple with the predicted and actual label
		JavaRDD<Tuple2<Object, Object>> scoreAndLabels = testLabeled.map(line ->
		  			new Tuple2<>(model.predict(line.features()),line.label()));
		//Instantiating a metrics object
		BinaryClassificationMetrics metrics=new BinaryClassificationMetrics(JavaRDD.toRDD(scoreAndLabels));
		//Calculating Area under the curve
		double auROC = metrics.areaUnderROC();
		System.out.println("Area under ROC = " + auROC);
		//Closing the spark context
		sc.close();
	}
}
