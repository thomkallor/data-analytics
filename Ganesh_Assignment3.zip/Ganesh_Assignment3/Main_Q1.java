package assignment3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import assignment3.Measurement_Q1;
import assignment3.WeatherStation_Q1;

public class Main_Q1 {
	public static void main(String[] args) {
		//Creating a list of measurements
		List<Measurement_Q1> measurements= new ArrayList<>(
				Arrays.asList(new Measurement_Q1(12,23.5795),
						new Measurement_Q1(13,12.567),
						new Measurement_Q1(13,12.97),
						new Measurement_Q1(14,30.7987),
						new Measurement_Q1(10,18.567),
						new Measurement_Q1(4,14.8967))
				);
		//Creating weather station Dublin using the measurements created
		WeatherStation_Q1 dublin=new WeatherStation_Q1("Dublin",measurements);
		//Creating weather station Galway using the measurements created
		WeatherStation_Q1 galway=new WeatherStation_Q1("Galway",measurements);
		//Adding the stations created to the static variable in WeatherStation Class
		WeatherStation_Q1.stations.add(dublin);
		WeatherStation_Q1.stations.add(galway);
		//Calling countTemperatures with 12 as input
		System.out.println("Number of temperature in the range provided is "+WeatherStation_Q1.countTemperatures(12));
	}

}
