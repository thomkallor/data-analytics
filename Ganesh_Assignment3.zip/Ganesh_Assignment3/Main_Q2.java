package assignment3;

public class Main_Q2 {
	public static void main(String[] args) {
		//Calling the analyse method to train and test the model
		SentimentAnalysis_Q2.analyse();
	}
}
