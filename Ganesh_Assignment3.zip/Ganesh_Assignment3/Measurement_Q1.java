package assignment3;

import java.io.Serializable;

public class Measurement_Q1 implements Serializable {
	private static final long serialVersionUID = 2375238687801168601L;
	public int time;
	public double temperature;

	//Constructor to instantiate object with given values
	public Measurement_Q1(int time,double temperature){
		this.time=time;
		this.temperature=temperature;
	}
}
