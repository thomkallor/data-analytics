package assignment5;

import org.apache.spark.SparkConf;
import org.apache.spark.streaming.*;
import org.apache.spark.streaming.twitter.*;
import org.apache.spark.streaming.api.java.*;
import twitter4j.*;

import java.io.Serializable;
import java.util.Arrays;

import scala.Tuple2;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

public class Twitter implements Serializable {

	private static final long serialVersionUID = 1L;

	public void process() {
		String consumerKey = "sQjPK7PwIHbH78q8d65FLrlhj";
		String consumerSecret = "9lr0K0OKwlVrJUek1l9j5zQccIJ3JmudmtSiFEYCt6wYEzdNu5";
		String accessToken = "991006554-pho5L5qR2GjDkyeRqteoFZB6yqBnG6o4wkzTYZDr";
		String accessTokenSecret = "p8NAUPgB9xod4jlbagde88l5YQIGFtTXcujZY43i7yM1p";

		// Disable logs twitter
		Logger.getLogger("org").setLevel(Level.OFF);
		Logger.getLogger("akka").setLevel(Level.OFF);

		// window and slide duration required
		Duration window = Durations.minutes(5);
		Duration slide = Durations.seconds(30);
		
		// twitter authentication settings
		System.setProperty("twitter4j.oauth.consumerKey", consumerKey);
		System.setProperty("twitter4j.oauth.consumerSecret", consumerSecret);
		System.setProperty("twitter4j.oauth.accessToken", accessToken);
		System.setProperty("twitter4j.oauth.accessTokenSecret", accessTokenSecret);

		SparkConf conf = new SparkConf().setAppName("Twitter-assignment").setMaster("local[4]")
				.set("spark.executor.memory", "1g");
		// create java streaming context with interval 1 second
		JavaStreamingContext jssc = new JavaStreamingContext(conf, new Duration(1000));
		JavaReceiverInputDStream<Status> stream = TwitterUtils.createStream(jssc);

		// get the tweets text form the stream
		JavaDStream<String> tweets = stream.map(status -> status.getText());

		// printing tweets
		tweets.foreachRDD(tweetRDD -> {
			tweetRDD.foreach(tweet -> {
				System.out.println("Tweet :" + tweet);
			});
		});

		// Words in each tweet
		JavaDStream<String> words = tweets.flatMap(tweet -> Arrays.asList(tweet.split(" ")).iterator());

		// split using spaces and get words count
		JavaDStream<Tuple2<Integer, Integer>> wordCountPairs = tweets
				.map(tweet -> new Tuple2<>(tweet.split(" ").length, 1));

		// printing word count
		wordCountPairs.foreachRDD(wordCount -> {
			wordCount.foreach(wordPair -> {
				System.out.println("Tweet word count :" + wordPair._1());
			});
		});

		// character count in each tweet
		JavaDStream<Tuple2<Integer, Integer>> charCountPairs = tweets.map(tweet -> new Tuple2<>(tweet.length(), 1));

		// printing tweet character count
		charCountPairs.foreachRDD(charCount -> {
			charCount.foreach(charPair -> {
				System.out.println("Tweet character count :" + charPair._1());
			});
		});

		// filter the words that starts with # (hashtags)
		JavaDStream<String> hashTags = words.filter(word -> word.startsWith("#"));

		// print the hashtags
		hashTags.foreachRDD(hashTagRDD -> {
			hashTagRDD.foreach(hashTag -> {
				System.out.println("Hashtags in tweet :" + hashTag);
			});
		});

		// Sum the number of characters and the number of tweets calculated for each tweet (character count, tweet count pairs)
		JavaDStream<Tuple2<Integer, Integer>> charSums = charCountPairs.reduce((charPair1, charPair2) -> {
			return new Tuple2<>(charPair1._1() + charPair2._1(), charPair1._2() + charPair2._2());
		});

		// Sum the number of words and the number of tweets calculated for each tweet (word count, tweet count pairs)
		JavaDStream<Tuple2<Integer, Integer>> wordSums = wordCountPairs.reduce((wordPair1, wordPair2) -> {
			return new Tuple2<>(wordPair1._1() + wordPair2._1(), wordPair1._2() + wordPair2._2());
		});

		// Sum the number of characters and the number of tweets in each window (character count, tweet count pairs)
		JavaDStream<Tuple2<Integer, Integer>> charSumsWindowed = charCountPairs
				.reduceByWindow((charPair1, charPair2) -> {
					return new Tuple2<>(charPair1._1() + charPair2._1(), charPair1._2() + charPair2._2());
				}, window, slide);

		// Sum the number of words and the number of tweets in each window (word count, tweet count pairs)
		JavaDStream<Tuple2<Integer, Integer>> wordSumsWindowed = wordCountPairs
				.reduceByWindow((wordPair1, wordPair2) -> {
					return new Tuple2<>(wordPair1._1() + wordPair2._1(), wordPair1._2() + wordPair2._2());
				}, window, slide);

		// Calculate average of characters in each tweet without window
		JavaDStream<Integer> charAverage = charSums.map(sumPair -> sumPair._1() / sumPair._2());

		// printing character averages without window
		charAverage.foreachRDD(averageRDD -> {
			averageRDD.foreach(averageChar -> {
				System.out.println("Tweet character average without window :" + averageChar);
			});
		});

		// Calculate average of words in each tweet without window
		JavaDStream<Integer> wordAverage = wordSums.map(sumPair -> sumPair._1() / sumPair._2());

		// printing word averages without window
		wordAverage.foreachRDD(averageRDD -> {
			averageRDD.foreach(averageWord -> {
				System.out.println("Tweet word average without window :" + averageWord);
			});
		});

		// Calculate average of characters in each tweet for each window
		JavaDStream<Integer> charAverageWindowed = charSumsWindowed.map(sumPair -> sumPair._1() / sumPair._2());

		// printing character averages with window
		charAverageWindowed.foreachRDD(averageRDD -> {
			averageRDD.foreach(averageChar -> {
				System.out.println("Tweet character average with window :" + averageChar);
			});
		});

		// Calculate average of words in each tweet for each window
		JavaDStream<Integer> wordAverageWindowed = wordSumsWindowed.map(sumPair -> sumPair._1() / sumPair._2());

		// printing word averages with window
		wordAverageWindowed.foreachRDD(averageRDD -> {
			averageRDD.foreach(averageWord -> {
				System.out.println("Tweet word average with window :" + averageWord);
			});
		});

		// pairing hashtags to count (hashtag,1)
		JavaPairDStream<String, Integer> hashTagCount = hashTags.mapToPair(word -> new Tuple2<>(word.substring(1), 1));
		
		// sum of hashtags to count (hashtag,sum) without window
		JavaPairDStream<String, Integer> hashTagTotals = hashTagCount.reduceByKey((a, b) -> a + b);

		// sum of hashtags to count (hashtag,sum) with window
		JavaPairDStream<String, Integer> hashTagTotalsWindowed = hashTagCount.reduceByKeyAndWindow((a, b) -> a + b, window,
				slide);

		// swap to sort by key without window
		JavaPairDStream<Integer, String> hashTagsSwap = hashTagTotals.mapToPair(hashTagPair -> hashTagPair.swap());

		// Print top 10 hashtag without window
		hashTagsSwap.foreachRDD(hashTagRDD -> {
			System.out.println("Top 10 hash tags without window:");
			for (Tuple2<Integer, String> hashTagPair : hashTagRDD.sortByKey(false).take(10)) {
				System.out.println(hashTagPair._2() + "   Count: " + hashTagPair._1());
			}
		});
		
		// swap to sort by key with window
		JavaPairDStream<Integer, String> hashTagsSwapWindowed = hashTagTotalsWindowed.mapToPair(hashTagPair -> hashTagPair.swap());

		// Print top 10 hashtag with window
		hashTagsSwapWindowed.foreachRDD(hashTagRDD -> {
			System.out.println("Top 10 hash tags with window:");
			for (Tuple2<Integer, String> hashTagPair : hashTagRDD.sortByKey(false).take(10)) {
				System.out.println(hashTagPair._2() + "   Count: " + hashTagPair._1());
			}
		});

		// start the stream context
		jssc.start();
		try {
			jssc.awaitTermination();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
