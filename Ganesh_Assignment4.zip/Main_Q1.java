package assignment4;

public class Main_Q1 {
	public static void main(String[] args) {
		Kmeans_Q1.classify();
	}
}
