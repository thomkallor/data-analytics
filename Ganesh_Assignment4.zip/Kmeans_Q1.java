package assignment4;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.mllib.clustering.KMeansModel;
import org.apache.spark.mllib.clustering.KMeans;
import org.apache.spark.mllib.linalg.Vector;
import org.apache.spark.mllib.linalg.Vectors;

import scala.Tuple2;

public class Kmeans_Q1 {
	public static void classify(){
		SparkConf conf = new SparkConf().setAppName("K-means").setMaster("local[4]").set("spark.executor.memory", "1g");
		
		//Initiating JavaSparkContext to work with Java collections
		JavaSparkContext sc = new JavaSparkContext(conf);
		String path="target/twitter2D.txt";
		
		//Load the file
		JavaRDD<String> data = sc.textFile(path);
		
		// split the lines in data and vectorize only the coordinates
		// making pairs of (tweet,vector)
		JavaPairRDD<String,Vector> featuresPaired = data.mapToPair(
					(String line) -> {
					String[] features = line.split(",");
					double[] values = new double[2];
					for (int i = 0; i < 2; i++)
						values[i] = Double.parseDouble(features[i]);
					return new Tuple2<>(features[features.length-1], Vectors.dense(values));
					}
				);
		
		int numClusters = 4;
		int numIterations = 200;
		
		//train the kmeans model with 4 clusters(classes) and 200 iterations
		KMeansModel clusters = KMeans.train(featuresPaired.values().rdd(), numClusters, numIterations);

		//Predicts and stores the data in a (prediction,tweet) 
		JavaPairRDD<Integer,String> predictions= featuresPaired.mapToPair(
					(line) -> {
						String tweet=line._1();
						Vector features= line._2();
						return new Tuple2<>(clusters.predict(features),tweet);
					}
				);
		//sorts the predicted value by key(prediction) and prints it
		predictions.sortByKey().collect().forEach(line->System.out.println("Tweet \""+line._2() +"\" is in cluster "+ line._1()));
		sc.close();
	}
}
